
<div class="title">
	<h1>Yeah WRITE!</h1>
	<h3>Your library. Your stories.</h3>
</div>

<div>	

<nav class="primary-menu">
   <ul>
      <li><a href="index.php">About</a></li>
      <li><a href="submit.php">Submit Your Work</a></li>
      <li><a href="#">Contact</a></li>
   </ul>
</nav>

<div class="search">
	<input type="text"> <input type="submit" value="search">
</div>

</div>