<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Yeah WRITE!</title>
  <meta name="description" content="This page discusses human augmentation and assistive technology for INFO 140 assignment 13.">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@800&display=swap" rel="stylesheet">
</head>

<body>

<div class="page-wrapper">
<header class="banner">

<?php include('includes/banner.php');?>
		
</header>

<main>

<h2>Assistive Technology, Human Augmentation, and 2021 Trends</h2>

<p>As someone in the LIS field, it is important to keep abreast of the latest trends and development in technology. Getting in the habit of trendwatching is important to be able to ride the wave of popular and growing technology as we navigate the new world of libraries. Fortunately, experts in the field of trendwatching are eager to share their predictions for what’s next in technology, and an exciting trend to watch out for seems to be human-centered coding.</p>

<p>One such trend for 2021 as noted by Alexey Makarov, CEO and founder of Qulix Systems, is that of human augmentation (2020). Human augmentation is “a set of technologies that is used to enhance, replace or complement the natural abilities of people” (Makarov, 2020). One example of such technology is that of google glass. As Professor Dean reminds us often in his lectures, humans and how to connect to them should always be at the focus of why we code. If coding and technology are not accessible to everyone, they are not worth much. This trend of human augmentation is aligned similarly with the concept of assistive technology for people with disabilities.</p>

<p>Assistive technology is described as “any device, software, or equipment that helps people work around their challenges” (Krasniansky, 2020). What sets assistive technology apart from human augmentation is that it is specifically tailored to a subset of people with a disability to transform their life. So what begins as assistive technology can eventually make its way into the mainstream of technology and impact the rest of consumers. In fact this is often the case:  many technologies we think of as for everyone now began as assistive technology.</p>

<p>One such example of this phenomenon is in online testing in the education field. The need for specificity in design does not only benefit niche groups, but rather can be used by and understood by all. Universal design for learning (UDL) “calls for students to be presented with information and content in different ways and for providing multiple options to show understanding” (Davis, 2014). Computer-based exams that allow for magnifying text, text-to-speech tools, and more can be navigated by all students for a more accessible learning environment for everyone.</p>

<p>We are seeing this trend play out even more in real time during the current pandemic. As someone who puts on events for the public, the transition to virtual programming has allowed me to reach people with disabilities who have difficulties making it to in-person events and classes. People are now more aware than ever of technology. Therefore there has never been a better time than now to center the experiences of people with disabilities and ensure we continue to provide accessible spaces well into the future.</p>

<h3>References</h3>

<p>Davis, M. R. (2014, March 14). Assistive tech for testing merges into mainstream. Education Week. <a href="https://www.edweek.org/ew/articles/2014/03/13/25assistive.h33.html" target="_blank">https://www.edweek.org/ew/articles/2014/03/13/25assistive.h33.html</a></p>

<p>Krasniansky, A. (2020, February 26). New technologies are empowering persons with disabilities. But are they assistive? Bill of Health. <a href="https://blog.petrieflom.law.harvard.edu/2020/02/26/new-technologies-are-empowering-persons-with-disabilities-but-are-they-assistive/" target="_blank">https://blog.petrieflom.law.harvard.edu/2020/02/26/new-technologies-are-empowering-persons-with-disabilities-but-are-they-assistive/</a></p>

<p>Makarov, A. (2020, October 14). Nine software development trends in 2021 to watch for now. Forbes. <a href="https://www.forbes.com/sites/forbestechcouncil/2020/10/14/nine-software-development-trends-in-2021-to-watch-for-now/?sh=2768e8942e19" target="_blank">https://www.forbes.com/sites/forbestechcouncil/2020/10/14/nine-software-development-trends-in-2021-to-watch-for-now/?sh=2768e8942e19</a></p>

</main>

<aside class="sidebar">

<h2>aside content</h2>
<p>Vivamus et lacus eget massa mollis blandit et ac augue. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. In luctus arcu vitae sapien lobortis tempus. Vestibulum eu enim elit, eget egestas dui. Nam nec eleifend magna. Sed quis magna in est elementum pretium. Fusce sagittis sollicitudin lorem, vel ultrices nulla convallis ac. Suspendisse arcu dui, eleifend sed vulputate vitae, imperdiet a libero. Aenean condimentum pellentesque arcu, id tincidunt ipsum egestas sit amet.</p>

<p>In posuere laoreet enim, vitae sollicitudin arcu porta aliquam. Pellentesque ipsum urna, venenatis vitae pellentesque vitae, elementum in dui. Cras orci eros, interdum non gravida sed, ultricies ac enim.</p>

</aside>

<footer class="site-footer">

<?php include('includes/footer.php');?>

</footer>

</div> <!-- end of page-wrapper div -->

</body>
</html>