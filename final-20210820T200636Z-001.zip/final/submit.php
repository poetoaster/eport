<?php include('includes/process.php');?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Submit Your Work - Yeah WRITE!</title>
  <meta name="description" content="Submit your writing piece to our site to be included in our online archive.">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@800&display=swap" rel="stylesheet">
</head>

<body>

<div class="page-wrapper">
<header class="banner">

<?php include('includes/banner.php');?>
		
</header>

<main>

<h2>Submit Your Work to Our Archive!</h2>

<?php print $formMessage;?>

<form class="submit-your-work" method="post">

<label for="name">Name</label>
<input type="text" id="name" name="name">

<label for="email">Email</label>
<input type="text" id="email" name="email">

<label for="title">Title of Work</label>
<input type="text" id="title" name="title">
 
<fieldset>
 
        <legend>publication level</legend>
 
        <label>Publish to site <input type="radio" name="publication level" value="publish to site"></label>      

        <label>Include in newsletter/external advertisement <input type="radio" name="publication level" value="include in newsletter/external advertisement"></label>
				
		<label>All publication forms are permissible for my work <input type="radio" name="publication level" value="all publication forms are permissible for my work"></label>

</fieldset>
 
<fieldset>

        <legend>genre</legend>
       
        <label>Poetry <input type="checkbox" name="genre[]" value="poetry"></label>
               
        <label>Horror <input type="checkbox" name="genre[]" value="horror"></label>
       
        <label>Prose <input type="checkbox" name="genre[]" value="prose"></label>
		
		<label>Fiction <input type="checkbox" name="genre[]" value="fiction"></label>
		
		<label>Nonfiction <input type="checkbox" name="genre[]" value="nonfiction"></label>
		
		<label>Romance <input type="checkbox" name="genre[]" value="romance"></label>
		
		<label>Fantasy <input type="checkbox" name="genre[]" value="fantasy"></label>
		
		<label>Other <input type="checkbox" name="genre[]" value="other"></label>
 
</fieldset>

<label for="other-genre">If you checked "Other," please specify unlisted genres here:</label>
<textarea name="other-genre" id="other-genre"></textarea>
       
<label for="your-work">Your Work</label>
<textarea name="your-work" id="your-work"></textarea>

<label for="newsletter">Would you like to subscribe to our newsletter?</label>
<select name="newsletter" id="newsletter">
        <option value="no">No</option>
        <option value="yes">Yes</option>
</select>

<input type="submit" value="submit form">

</form>

<script>
	document.querySelector (".submit-your-work").onsubmit = function() {
	alert("Thank you for submitting your work!");
	}
</script>

<script>
	window.onload = function() {
   
    document.querySelector('.submit-your-work').onsubmit = function() {

    var newsLetter = document.getElementById('newsletter');
       
    if(newsLetter.value == 'no') {
       
      alert('Please consider subscribing!');
        return false;   
      }   
	  
    else {
      alert("Thank you for submitting your work!");
       }   
	  }
       
	}
</script>

</main>

<aside class="sidebar">

<?php include('includes/aside.php');?>

</aside>

<footer class="site-footer">

<?php include('includes/footer.php');?>

</footer>

</div> <!-- end of page-wrapper div -->

</body>
</html>