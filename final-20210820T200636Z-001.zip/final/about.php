<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>About - Yeah WRITE!</title>
  <meta name="description" content="Find out what Yeah WRITE is all about.">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@800&display=swap" rel="stylesheet">
</head>

<body>

<div class="page-wrapper">
<header class="banner">

<?php include('includes/banner.php');?>
		
</header>

<main>

<h2>So what's the deal about Yeah WRITE?</h2>
<h3>Join a community of local authors and submit your work to our virtual library!</h3>

<p>So what is this all about? It's simple: if you're a writer and you want to be submitted to our archive, go for it! We want to reach local authors, and online, local is relative! You may not be located in the same city as our library, but if you found your way to this site, then congratulations, you have a place in this archive.</p>

<p>The following research paper is what started me thinking seriously about how the library interacts with local writers, including those of the fanfic community. Since the fanfic community is largely an online one, it makes sense for the library to provide a hosting site for fanfic writers and beyond. Local authors in particular are often snubbed by libraries if they are self published or not published at all. Yeah, Write! aims to band local and fanfic authors together and celebrate their works at the library.</p>

<p><iframe class="embed" src="https://docs.google.com/document/d/e/2PACX-1vSgr-6np00Q52NGZTC04gK6yQwX5reb5lPv2H0-BwJ1KmXBnuQSEFJn_5OhwBWKw1TF_qQJf2SobcQI/pub?embedded=true"></iframe></p>

</main>

<aside class="sidebar">

<?php include('includes/aside.php');?>

</aside>

<footer class="site-footer">

<?php include('includes/footer.php');?>
	
</footer>

</div> <!-- end of page-wrapper div -->

</body>
</html>