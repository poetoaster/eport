
<div class="title">
	<a href="index.php"><img class="logo" src="images/yeahwrite.png" width=250 height=250 alt="Logo 'Yeah WRITE' with the tag 'Your library. Your stories.' and a quill"></a>
</div>

<div>	

<nav class="primary-menu">
   <ul>
      <li><a href="submit.php">Submit</a></li>
      <li><a href="about.php">About</a></li>
      <li><a href="faq.php">FAQs</a></li>
      <li><a href="contact.php">Contact</a></li>
   </ul>
</nav>

<div class="search">
	<input type="text"> <input type="submit" value="search">
</div>

</div>