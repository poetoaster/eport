<h2>A Writer's Resources</h2>

<img class="aside-image" src="images/writerresources.jpg" width=2800 height=2100 alt="A man sits down on a curb to write something down">

<p>Every writer's got their toolkit- usually that includes a writing implement and something to write on, or a computer- hey, even typing out that fresh idea as a draft on your phone.</p> 

<p>Beyond your basic toolkit, here are a few stellar resources we recommend to hone your skills and confidence so you can feel really great about submitting your piece to us!</p>

<nav class="aside-menu">
   <ul>
      <li><a href="https://www.writersdigest.com/" target="_blank">Writer's Digest:</a> Sign up for daily writing prompts for a year, browse by type of writing, and get connected to a large community of fellow authors!</li>
      <li><a href="https://www.quickanddirtytips.com/grammar-girl" target="_blank">Grammar Girl:</a> Great advice on grammar tips and more, even in a handy podcast format!</li>
      <li><a href="https://nanowrimo.org/" target="_blank">NaNoWriMo:</a> Short for National Novel Writing Month, NaNoWriMo connects a community of authors for the month of November and beyond, encouraging them to write 40,000 words and begin editing their work afterwards.</li>
   </ul>
</nav>

<p>Got some more resources you think we should share with writers? Hit us up on social media or our <a href="contact.php">contact page</a> and let us share them on our site!</p>