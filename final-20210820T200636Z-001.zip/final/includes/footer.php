<div class="social-media">
	<ul>
		<li><a href="#">Facebook</a></li>
		<li><a href="#">IG</a></li>
		<li><a href="#">Twitter</a></li>			
		<li><a href="contact.php">Contact</a></li>
	</ul>
</div>