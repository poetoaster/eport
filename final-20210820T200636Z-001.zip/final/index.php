<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Yeah WRITE!</title>
  <meta name="description" content="Welcome to Yeah, WRITE!, a library's archive of local authors and fanfic writers.We hope you join our community!">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@800&display=swap" rel="stylesheet">
</head>

<body>

<div class="page-wrapper">
<header class="banner">

<?php include('includes/banner.php');?>
		
</header>

<main>

<h2>From poetry to fanfic to self-published work, add your piece to our growing collection</h2>
<h3>Join a community of local authors and submit your work to our virtual library!</h3>

<img class="story" src="images/yourstory.jpg" width=800 height=450 alt="An open journal with hand writing the words 'What's your story?'">

<p>Welcome, writers everywhere, to Yeah WRITE! This site was begun in the effort to connect local authors to each other and share their works. All too often, local artists of all kinds lack a central hub or organization to cheerlead and champion their work. Our library is seeking to change that and you can be a part of it! Joining our community and submitting to our archive will benefit you in the following ways:</p>

<ul>
	<li>Your work will be published to our site, bringing it to a wider audience</li>
	<li>You will have the opportunity to get connected to other authors featured in the archive for peer reviews, swapping writing tips, and general community</li>
	<li>You will be invited to exclusive writers workshops and clubs at our library</li>
	<li>And much, much more!</li>
</ul>

<p>So what are you waiting for? Whether you're a poet or a prose writer, or anything else within the scope of the written word, head on over to our <a href="submit.php">Submit Your Work page</a> and send us your stuff!</p>

</main>

<aside class="sidebar">

<?php include('includes/aside.php');?>

</aside>

<footer class="site-footer">

<?php include('includes/footer.php');?>
	
</footer>

</div> <!-- end of page-wrapper div -->

</body>
</html>