<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Contact - Yeah WRITE!</title>
  <meta name="description" content="Contact us with any questions.">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@800&display=swap" rel="stylesheet">
</head>

<body>

<div class="page-wrapper">
<header class="banner">

<?php include('includes/banner.php');?>
		
</header>

<main>

<h2>Contact Us!</h2>
<h3>Reach out with any questions, concerns, or ideas you have, or just to say hi! We'd love to hear from you.</h3>

<h4>Email us:</h4>
<p>emailaddress@library.org</p>

<h4>Send us a letter:</h4>
<p>Your Address, Your City, Your State USA</p>

<h4>Social Media Shoutouts:</h4>
	<ul>
		<li><a href="#">Facebook</a></li>
		<li><a href="#">IG</a></li>
		<li><a href="#">Twitter</a></li>			
		<li><a href="#">Contact</a></li>
	</ul>

</main>

<aside class="sidebar">

<?php include('includes/aside.php');?>

</aside>

<footer class="site-footer">

<?php include('includes/footer.php');?>
	
</footer>

</div> <!-- end of page-wrapper div -->

</body>
</html>