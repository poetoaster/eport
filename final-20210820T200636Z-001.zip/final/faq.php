<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Frequently Asked Questions - Yeah WRITE!</title>
  <meta name="description" content="See if your writing would fit with our archive!">
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Sansita+Swashed:wght@800&display=swap" rel="stylesheet">
</head>

<body>

<div class="page-wrapper">
<header class="banner">

<?php include('includes/banner.php');?>
		
</header>

<main>

<h2>Yeah WRITE! Frequently Asked Questions</h2>
<h3>Dispelling your insecurities so you can confidently submit your work</h3>

<p>"Can I submit my work?" You might be wondering. Maybe you don't think your work is ready, or good enough, or you have some other hesitation. In this space, we celebrate local authors, and if you write, that means YOU! Here are some examples of the kind of work we accept:</p>

<ul>
	<li>Audio Archive
		<ul>
			<li>Spoken Word</li>
			<li>Oral Stories</li>
		</ul>
	</li>
	<li>Memoir</li>
	<li>Fanfiction
		<ul>
			<li>Serial Fanfic</li>
			<li>Oneshot Fanfic</li>
			<li>Crossover Fic</li>
		</ul>
	</li>
	<li>Narrative Fiction</li>
	<li> <strong>If you're local and you've written something, just submit already! It has a place in our library!</strong></li>
</ul>

<p>Now that we've established that we're looking for a wide array of work, let's address that imposter syndrome so many creatives seem to have. Perhaps you've in the process of trying to get your work published, or nervous about submitting not just to this archive but to another publication. Here is a handy visual representation of some famous authors and how many times they were rejected before they finally got published. Keep trying, don't give up! An acceptance is just around the corner!</p>

<table>

	<caption>Learning from Failure</caption>
	
	<thead>
		<tr>
			<th>Book</th>
			<th>Author</th>
			<th>Times Rejected before Publication</th>
		</tr>
	</thead>
	
	<tbody>
			<tr>
			<td>Twilight</td>
			<td>Stephanie Meyers</td>
			<td>14</td>
		</tr>
		<tr>
			<td>A Wrinkle in Time</td>
			<td>Madeleine L'Engle</td>
			<td>26</td>
		</tr>
		<tr>
			<td>Carrie</td>
			<td>Stephen King</td>
			<td>30</td>
		</tr>
				<tr>
			<td>The Thomas Berryman Number</td>
			<td>James Patterson</td>
			<td>31</td>
		</tr>
		<tr>
			<td>Chicken Soup for the Soul</td>
			<td>Jack Canfield and Mark Victor Hansen</td>
			<td>144</td>
		</tr>

	</tbody>
	<tfoot>
		<tr>
			<td colspan="3"> Source: <a href="https://lithub.com/the-most-rejected-books-of-all-time/" target=blank title="The Most Rejected Books of All Time">The Most Rejected Books of All Time</a></td>
		</tr>
	</tfoot>
</table>

</main>

<aside class="sidebar">

<?php include('includes/aside.php');?>

</aside>

<footer class="site-footer">

<?php include('includes/footer.php');?>
	
</footer>

</div> <!-- end of page-wrapper div -->

</body>
</html>